export class AddVehicleDto{
    vehicleName: string;
    vehicleDescription: string;
    vehiclePriceWeekly: number;
    vehicleTypeId: number;
    vehicleUseTypeId: number;
    userId: number
}