export class AddUserDto{
    userName: string;
    userEmail: string;
    userPhone: number;
    userAddress: string;
    userTypeId: number;
}