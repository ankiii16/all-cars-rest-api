export class UpdateUserDto{
    id:number;
    userName: string;
    userEmail: string;
    userPhone: number;
    userAddress: string;
    userTypeId: number;
}