export class CreateUserTypeDto {}
