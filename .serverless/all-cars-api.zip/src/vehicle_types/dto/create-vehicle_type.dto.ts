export class CreateVehicleTypeDto {}
